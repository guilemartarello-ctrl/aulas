package com.kombok.sistema_eventos;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class SistemaEventosApplication {

    public static void main(String[] args) {
        // Inicializa o Spring Boot permitindo interfaces gráficas de Desktop (AWT/Swing)
        ConfigurableApplicationContext context = new SpringApplicationBuilder(SistemaEventosApplication.class)
                .headless(false)
                .run(args);

        // Abre a Tela de Login passando o contexto do Spring para ela
        java.awt.EventQueue.invokeLater(() -> {
            TelaLogin telaLogin = new TelaLogin(context);
            telaLogin.setVisible(true);
        });
    }
}