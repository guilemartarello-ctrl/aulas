package com.kombok.sistema_eventos;

import org.springframework.context.ConfigurableApplicationContext;
import javax.swing.*;
import java.awt.*;

public class TelaMenu extends javax.swing.JFrame {

    private final ConfigurableApplicationContext springContext;

    public TelaMenu(ConfigurableApplicationContext springContext) {
        this.springContext = springContext;
        
        criarLayoutMenu();
        setLocationRelativeTo(null); // Centraliza a janela no ecrã
    }

    private void criarLayoutMenu() {
        setTitle("Kombo K - Menu Principal");
        setSize(400, 350); // Aumentamos um pouco a altura para acomodar bem os botões
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(5, 1, 10, 10)); // Ajustado para 5 linhas (Título + 4 Botões)

        // Título do Painel
        JLabel lblTitulo = new JLabel("Painel de Controle - Kombo K", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 16));
        add(lblTitulo);

        // Botões do Menu
        JButton btnGerenciar = new JButton("Gerenciar Estoque / Equipamentos (CRUD)");
        JButton btnClientes = new JButton("Gerenciar Clientes do Sistema");
        JButton btnRelatorios = new JButton("Ver Relatórios e Insights");
        JButton btnSair = new JButton("Sair do Sistema");

        add(btnGerenciar);
        add(btnClientes); 
        add(btnRelatorios);
        add(btnSair);

        // Ação do Botão Gerenciar Estoque
        btnGerenciar.addActionListener(e -> {
            this.dispose(); // Fecha o menu
            new TelaEstoque(springContext).setVisible(true); 
        });

        // Ação do Botão Gerenciar Clientes (Abre a nova tela que você criou!)
        btnClientes.addActionListener(e -> {
            this.dispose(); // Fecha o menu
            new TelaClientes(springContext).setVisible(true); // Abre a listagem de clientes
        });

        // Ação do Botão Ver Relatórios e Insights
        btnRelatorios.addActionListener(e -> {
            this.dispose(); // Fecha o menu
            new TelaRelatorios(springContext).setVisible(true); // Abre as estatísticas
        });

        // Ação do Botão Sair
        btnSair.addActionListener(e -> System.exit(0));
    }
}