package com.kombok.sistema_eventos;

import javax.swing.*;
import java.awt.*;

public class TelaFormCliente extends javax.swing.JDialog {

    private JTextField txtNome, txtTelefone, txtEmail;
    private JButton btnSalvar;
    private Cliente cliente;
    private boolean salvo = false;

    public TelaFormCliente(Frame parent, Cliente cliente) {
        super(parent, "Dados do Cliente", true);
        this.cliente = cliente;
        
        criarLayout();
        if (cliente != null) {
            txtNome.setText(cliente.getNome());
            txtTelefone.setText(cliente.getTelefone());
            txtEmail.setText(cliente.getEmail());
        }
        setLocationRelativeTo(parent);
    }

    private void criarLayout() {
        setSize(350, 250);
        setLayout(new GridLayout(4, 2, 10, 10));

        add(new JLabel(" Nome:"));
        txtNome = new JTextField();
        add(txtNome);

        add(new JLabel(" Telefone:"));
        txtTelefone = new JTextField();
        add(txtTelefone);

        add(new JLabel(" Email:"));
        txtEmail = new JTextField();
        add(txtEmail);

        btnSalvar = new JButton("Salvar");
        add(btnSalvar);

        btnSalvar.addActionListener(e -> {
            if (txtNome.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Nome é obrigatório!");
                return;
            }
            if (cliente == null) cliente = new Cliente();
            cliente.setNome(txtNome.getText());
            cliente.setTelefone(txtTelefone.getText());
            cliente.setEmail(txtEmail.getText());
            salvo = true;
            dispose();
        });
    }

    public boolean isSalvo() { return salvo; }
    public Cliente getCliente() { return cliente; }
}