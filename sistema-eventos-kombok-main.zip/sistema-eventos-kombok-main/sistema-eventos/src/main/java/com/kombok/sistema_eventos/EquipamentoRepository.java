package com.kombok.sistema_eventos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EquipamentoRepository extends JpaRepository<Equipamento, Long> {
    // Não precisa escrever nenhum método aqui 
    // O JpaRepository já traz o salvar, deletar e buscar prontos por padrão.
}