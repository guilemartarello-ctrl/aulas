package com.kombok.sistema_eventos;

import org.springframework.context.ConfigurableApplicationContext;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class TelaEstoque extends javax.swing.JFrame {

    private final ConfigurableApplicationContext springContext;
    private final EquipamentoRepository repository;

    // Elementos da Interface
    private JTextField txtNome, txtCategoria, txtQuantidade, txtPreco;
    private JTable tabela;
    private DefaultTableModel modeloTabela;
    private Long idSelecionado = null;

    public TelaEstoque(ConfigurableApplicationContext springContext) {
        this.springContext = springContext;
        this.repository = springContext.getBean(EquipamentoRepository.class);

        txtNome = new JTextField(15);
        txtCategoria = new JTextField(10);
        txtQuantidade = new JTextField(5);
        txtPreco = new JTextField(7);

        criarLayout();
        atualizarTabela();
        setLocationRelativeTo(null);
    }

    private void criarLayout() {
        setTitle("Kombo K - Controle de Estoque");
        setSize(750, 450);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // Formulário Superior
        JPanel painelForm = new JPanel(new FlowLayout());
        painelForm.add(new JLabel("Nome:")); painelForm.add(txtNome);
        painelForm.add(new JLabel("Categoria:")); painelForm.add(txtCategoria);
        painelForm.add(new JLabel("Qtd:")); painelForm.add(txtQuantidade);
        painelForm.add(new JLabel("Preço R$:")); painelForm.add(txtPreco);

        // Grid Central (Tabela de Dados)
        modeloTabela = new DefaultTableModel(new Object[]{"ID", "Nome", "Categoria", "Estoque", "Preço Locação"}, 0);
        tabela = new JTable(modeloTabela);
        JScrollPane scroll = new JScrollPane(tabela);

        // Barra Inferior de Botões
        JPanel painelBotoes = new JPanel(new FlowLayout());
        JButton btnSalvar = new JButton("Salvar / Atualizar");
        JButton btnExcluir = new JButton("Excluir");
        JButton btnLimpar = new JButton("Limpar");
        JButton btnVoltar = new JButton("Voltar ao Menu");

        painelBotoes.add(btnSalvar);
        painelBotoes.add(btnExcluir);
        painelBotoes.add(btnLimpar);
        painelBotoes.add(btnVoltar);

        add(painelForm, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);
        add(painelBotoes, BorderLayout.SOUTH);

        // Eventos e Ações
        btnSalvar.addActionListener(e -> acaoSalvar());
        btnExcluir.addActionListener(e -> acaoExcluir());
        btnLimpar.addActionListener(e -> limparCampos());
        btnVoltar.addActionListener(e -> {
            this.dispose();
            new TelaMenu(springContext).setVisible(true);
        });

        // Clique na tabela joga os dados de volta para os campos de texto
        tabela.getSelectionModel().addListSelectionListener(e -> {
            int linha = tabela.getSelectedRow();
            if (linha != -1) {
                idSelecionado = (Long) modeloTabela.getValueAt(linha, 0);
                txtNome.setText((String) modeloTabela.getValueAt(linha, 1));
                txtCategoria.setText((String) modeloTabela.getValueAt(linha, 2));
                txtQuantidade.setText(modeloTabela.getValueAt(linha, 3).toString());
                txtPreco.setText(modeloTabela.getValueAt(linha, 4).toString());
            }
        });
    }

    private void atualizarTabela() {
        modeloTabela.setRowCount(0);
        List<Equipamento> lista = repository.findAll();
        for (Equipamento eq : lista) {
            modeloTabela.addRow(new Object[]{eq.getId(), eq.getNome(), eq.getCategoria(), eq.getQuantidadeEstoque(), eq.getPrecoLocacao()});
        }
    }

    private void acaoSalvar() {
        try {
            Equipamento eq = new Equipamento();
            if (idSelecionado != null) {
                eq.setId(idSelecionado);
            }
            eq.setNome(txtNome.getText());
            eq.setCategoria(txtCategoria.getText());
            eq.setQuantidadeEstoque(Integer.parseInt(txtQuantidade.getText()));
            eq.setPrecoLocacao(Double.parseDouble(txtPreco.getText()));

            repository.save(eq);
            JOptionPane.showMessageDialog(this, "Item registrado com sucesso!");
            limparCampos();
            atualizarTabela();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Verifique os dados numéricos informados!", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void acaoExcluir() {
        if (idSelecionado != null) {
            repository.deleteById(idSelecionado);
            JOptionPane.showMessageDialog(this, "Item removido com sucesso!");
            limparCampos();
            atualizarTabela();
        } else {
            JOptionPane.showMessageDialog(this, "Selecione uma linha da tabela para excluir.");
        }
    }

    private void limparCampos() {
        idSelecionado = null;
        txtNome.setText("");
        txtCategoria.setText("");
        txtQuantidade.setText("");
        txtPreco.setText("");
        tabela.clearSelection();
    }
}