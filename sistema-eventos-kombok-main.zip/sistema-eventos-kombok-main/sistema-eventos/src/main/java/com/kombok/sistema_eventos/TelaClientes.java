package com.kombok.sistema_eventos;

import org.springframework.context.ConfigurableApplicationContext;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class TelaClientes extends javax.swing.JFrame {

    private final ConfigurableApplicationContext springContext;
    private final ClienteRepository repository;
    private JTable tabela;
    private DefaultTableModel modeloTabela;

    public TelaClientes(ConfigurableApplicationContext springContext) {
        this.springContext = springContext;
        this.repository = springContext.getBean(ClienteRepository.class);

        criarLayout();
        atualizarTabela();
        setLocationRelativeTo(null);
    }

    private void criarLayout() {
        setTitle("Kombo K - Gerenciar Clientes");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // Tabela centralizada
        modeloTabela = new DefaultTableModel(new Object[]{"ID", "Nome", "Telefone", "Email"}, 0);
        tabela = new JTable(modeloTabela);
        add(new JScrollPane(tabela), BorderLayout.CENTER);

        // Painel de Botões Lateral
        JPanel painelBotoes = new JPanel(new GridLayout(4, 1, 5, 5));
        JButton btnNovo = new JButton("Novo Cliente");
        JButton btnEditar = new JButton("Editar");
        JButton btnExcluir = new JButton("Excluir");
        JButton btnVoltar = new JButton("Voltar Menu");

        painelBotoes.add(btnNovo);
        painelBotoes.add(btnEditar);
        painelBotoes.add(btnExcluir);
        painelBotoes.add(btnVoltar);
        add(painelBotoes, BorderLayout.EAST);

        // Ações dos botões
        btnNovo.addActionListener(e -> {
            TelaFormCliente form = new TelaFormCliente(this, null);
            form.setVisible(true);
            if (form.isSalvo()) {
                repository.save(form.getCliente());
                atualizarTabela();
            }
        });

        btnEditar.addActionListener(e -> {
            int linha = tabela.getSelectedRow();
            if (linha == -1) {
                JOptionPane.showMessageDialog(this, "Selecione um cliente na tabela para editar!");
                return;
            }
            Long id = (Long) modeloTabela.getValueAt(linha, 0);
            Cliente c = repository.findById(id).orElse(null);
            
            TelaFormCliente form = new TelaFormCliente(this, c);
            form.setVisible(true);
            if (form.isSalvo()) {
                repository.save(form.getCliente());
                atualizarTabela();
            }
        });

        btnExcluir.addActionListener(e -> {
            int linha = tabela.getSelectedRow();
            if (linha == -1) {
                JOptionPane.showMessageDialog(this, "Selecione um cliente na tabela para excluir!");
                return;
            }
            Long id = (Long) modeloTabela.getValueAt(linha, 0);
            repository.deleteById(id);
            atualizarTabela();
        });

        btnVoltar.addActionListener(e -> {
            this.dispose();
            new TelaMenu(springContext).setVisible(true);
        });
    }

    private void atualizarTabela() {
        modeloTabela.setRowCount(0);
        List<Cliente> lista = repository.findAll();
        for (Cliente c : lista) {
            modeloTabela.addRow(new Object[]{c.getId(), c.getNome(), c.getTelefone(), c.getEmail()});
        }
    }
}