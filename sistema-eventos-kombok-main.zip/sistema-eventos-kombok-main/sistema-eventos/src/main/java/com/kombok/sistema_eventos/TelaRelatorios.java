package com.kombok.sistema_eventos;

import org.springframework.context.ConfigurableApplicationContext;
import javax.swing.*;
import java.awt.*;
import java.util.List;

public class TelaRelatorios extends javax.swing.JFrame {

    private final ConfigurableApplicationContext springContext;
    private final EquipamentoRepository repository;

    // Componentes de texto para exibir os insights
    private JLabel lblTotalItens;
    private JLabel lblValorPatrimonio;
    private JLabel lblPrecoMedio;

    public TelaRelatorios(ConfigurableApplicationContext springContext) {
        this.springContext = springContext;
        this.repository = springContext.getBean(EquipamentoRepository.class);

        criarLayout();
        calcularEstatisticas();
        setLocationRelativeTo(null); // Centraliza a janela
    }

    private void criarLayout() {
        setTitle("Kombo K - Relatórios e Insights");
        setSize(450, 320);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(15, 15));

        // Título Superior
        JLabel lblTitulo = new JLabel("Painel de Insights do Estoque", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 18));
        add(lblTitulo, BorderLayout.NORTH);

        // Painel Central com as métricas (organizado em Grid)
        JPanel painelMetricas = new JPanel(new GridLayout(3, 1, 10, 10));
        painelMetricas.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        lblTotalItens = new JLabel("Total de Equipamentos em Estoque: 0");
        lblTotalItens.setFont(new Font("Arial", Font.PLAIN, 14));

        lblValorPatrimonio = new JLabel("Valor Total do Patrimônio: R$ 0,00");
        lblValorPatrimonio.setFont(new Font("Arial", Font.PLAIN, 14));

        lblPrecoMedio = new JLabel("Preço Médio de Locação: R$ 0,00");
        lblPrecoMedio.setFont(new Font("Arial", Font.PLAIN, 14));

        painelMetricas.add(lblTotalItens);
        painelMetricas.add(lblValorPatrimonio);
        painelMetricas.add(lblPrecoMedio);
        add(painelMetricas, BorderLayout.CENTER);

        // Painel Inferior com Botão Voltar
        JPanel painelBaixo = new JPanel(new FlowLayout());
        JButton btnVoltar = new JButton("Voltar ao Menu Principal");
        painelBaixo.add(btnVoltar);
        add(painelBaixo, BorderLayout.SOUTH);

        // Ação do Botão Voltar
        btnVoltar.addActionListener(e -> {
            this.dispose();
            new TelaMenu(springContext).setVisible(true);
        });
    }

    private void calcularEstatisticas() {
        List<Equipamento> equipamentos = repository.findAll();

        int totalItens = 0;
        double valorPatrimonio = 0.0;
        double somaPrecosLocacao = 0.0;

        for (Equipamento eq : equipamentos) {
            totalItens += eq.getQuantidadeEstoque();
            // Patrimônio = quantidade em estoque * preço de locação (ou custo)
            valorPatrimonio += (eq.getQuantidadeEstoque() * eq.getPrecoLocacao());
            somaPrecosLocacao += eq.getPrecoLocacao();
        }

        double precoMedio = equipamentos.isEmpty() ? 0.0 : (somaPrecosLocacao / equipamentos.size());

        // Atualiza os textos da tela com os dados reais do banco H2
        lblTotalItens.setText("Total de Equipamentos em Estoque: " + totalItens);
        lblValorPatrimonio.setText(String.format("Valor Total Estimado de Locação: R$ %.2f", valorPatrimonio));
        lblPrecoMedio.setText(String.format("Preço Médio por Locação: R$ %.2f", precoMedio));
    }
}