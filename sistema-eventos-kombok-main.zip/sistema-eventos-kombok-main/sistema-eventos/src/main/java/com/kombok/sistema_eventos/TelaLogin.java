package com.kombok.sistema_eventos;

import org.springframework.context.ConfigurableApplicationContext;
import javax.swing.*;
import java.awt.*;

public class TelaLogin extends javax.swing.JFrame {

    private final ConfigurableApplicationContext springContext;
    private final EquipamentoRepository equipamentoRepository;
    
    // Componentes da tela
    private JTextField txtUsuario;
    private JPasswordField txtSenha;
    private JButton btnEntrar;

    public TelaLogin(ConfigurableApplicationContext springContext) {
        this.springContext = springContext;
        this.equipamentoRepository = springContext.getBean(EquipamentoRepository.class);
        
        criarLayoutManual();
        setLocationRelativeTo(null); // Centraliza na tela
    }

    private void criarLayoutManual() {
        setTitle("Kombo K - Login");
        setSize(350, 220);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Label Usuário
        gbc.gridx = 0; gbc.gridy = 0;
        add(new JLabel("Usuário (admin):"), gbc);

        // Campo Usuário
        txtUsuario = new JTextField(15);
        gbc.gridx = 1; gbc.gridy = 0;
        add(txtUsuario, gbc);

        // Label Senha
        gbc.gridx = 0; gbc.gridy = 1;
        add(new JLabel("Senha (1234):"), gbc);

        // Campo Senha
        txtSenha = new JPasswordField(15);
        gbc.gridx = 1; gbc.gridy = 1;
        add(txtSenha, gbc);

        // Botão Entrar
        btnEntrar = new JButton("Entrar");
        gbc.gridx = 0; gbc.gridy = 2;
        gbc.gridwidth = 2;
        add(btnEntrar, gbc);

        // Ação do Botão
        btnEntrar.addActionListener(e -> realizarLogin());
    }

    private void realizarLogin() {
        String usuario = txtUsuario.getText();
        String senha = new String(txtSenha.getPassword());

        if (usuario.equals("admin") && senha.equals("1234")) {
            JOptionPane.showMessageDialog(this, "Login realizado com sucesso!");
            this.dispose(); // Fecha a tela de login
            
            // AGORA USAMOS A VARIÁVEL: Isso fará o aviso laranja sumir!
            new TelaMenu(springContext).setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this, "Usuário ou senha incorretos!", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
}