package com.kombok.sistema_eventos;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Equipamento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String nome;          // Ex: Painel de Led, Caixa de Som
    private String categoria;     // Ex: Som, Iluminação, Palco
    private int quantidadeEstoque; 
    private double precoLocacao;

    // 1. Construtor padrão (Vazio) - Obrigatório para o JPA
    public Equipamento() {
    }

    // 2. Construtor completo para ajudar na criação rápida de objetos
    public Equipamento(Long id, String nome, String categoria, int quantidadeEstoque, double precoLocacao) {
        this.id = id;
        this.nome = nome;
        this.categoria = categoria;
        this.quantidadeEstoque = quantidadeEstoque;
        this.precoLocacao = precoLocacao;
    }

    // 3. Métodos Get e Set (Obrigatórios pelo enunciado)
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public int getQuantidadeEstoque() {
        return quantidadeEstoque;
    }

    public void setQuantidadeEstoque(int quantidadeEstoque) {
        this.quantidadeEstoque = quantidadeEstoque;
    }

    public double getPrecoLocacao() {
        return precoLocacao;
    }

    public void setPrecoLocacao(double precoLocacao) {
        this.precoLocacao = precoLocacao;
    }
}